original_list=[{'_id': "ObjectId"('67bd6ea2e63d06c897d0de23')}, {'_id': "ObjectId"('67bd6ec57dbd058b9f0d999f')}]


for original in original_list:
    print(original)