from PySide6.QtCore import Signal
class EmitterParent:
    subwin_emitter = Signal()